require('dotenv').config();
const express = require('express');
const path = require('path');
const paymentRoutes = require('./routes/payment');

const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/pay', paymentRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Payment site running at ${process.env.BASE_URL || `http://localhost:${PORT}`}`);
});
