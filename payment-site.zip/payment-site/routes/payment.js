// routes/payment.js
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const bkash = require('../services/bkash');
const nagad = require('../services/nagad');

const router = express.Router();

// --- Very simple in-memory order store. Swap for a real database. ---
const orders = new Map();
// order shape: { id, amount, method, status, meta }

function createOrder(amount) {
  const id = uuidv4();
  orders.set(id, { id, amount, status: 'pending', method: null, meta: {} });
  return orders.get(id);
}

// ---------------------------------------------------------------------
// 1. Create an order and kick off payment with the chosen method
//    POST /api/pay  { amount, method: "bkash" | "nagad" }
// ---------------------------------------------------------------------
router.post('/pay', async (req, res) => {
  try {
    const { amount, method } = req.body;

    if (!amount || Number(amount) <= 0) {
      return res.status(400).json({ error: 'A valid amount is required.' });
    }
    if (!['bkash', 'nagad'].includes(method)) {
      return res.status(400).json({ error: 'method must be "bkash" or "nagad".' });
    }

    const order = createOrder(amount);
    order.method = method;

    if (method === 'bkash') {
      const callbackURL = `${process.env.BASE_URL}/api/pay/bkash/callback`;
      const result = await bkash.createPayment({
        amount,
        orderId: order.id,
        callbackURL,
      });
      order.meta.paymentID = result.paymentID;
      return res.json({ redirectUrl: result.bkashURL, orderId: order.id });
    }

    // method === 'nagad'
    const clientIp = req.ip;
    const init = await nagad.initializePayment({ orderId: order.id, clientIp });
    const callbackURL = `${process.env.BASE_URL}/api/pay/nagad/callback`;
    const complete = await nagad.completePayment({
      orderId: order.id,
      paymentReferenceId: init.paymentReferenceId,
      challenge: init.challenge,
      amount,
      callbackURL,
      clientIp,
    });
    order.meta.paymentReferenceId = init.paymentReferenceId;
    return res.json({ redirectUrl: complete.callBackUrl, orderId: order.id });
  } catch (err) {
    console.error(err.response?.data || err.message);
    res.status(500).json({ error: 'Failed to start payment. Check server logs.' });
  }
});

// ---------------------------------------------------------------------
// 2. bKash redirects here after the user approves/cancels payment
//    GET /api/pay/bkash/callback?paymentID=...&status=success|cancel|failure
// ---------------------------------------------------------------------
router.get('/bkash/callback', async (req, res) => {
  const { paymentID, status } = req.query;

  if (status !== 'success') {
    return res.redirect(`/cancel.html?method=bkash&status=${status}`);
  }

  try {
    const result = await bkash.executePayment(paymentID);
    const order = [...orders.values()].find((o) => o.meta.paymentID === paymentID);

    if (result.transactionStatus === 'Completed') {
      if (order) order.status = 'paid';
      return res.redirect(`/success.html?orderId=${order?.id || ''}&trxID=${result.trxID}`);
    }
    if (order) order.status = 'failed';
    return res.redirect(`/cancel.html?method=bkash&status=execute_failed`);
  } catch (err) {
    console.error(err.response?.data || err.message);
    return res.redirect(`/cancel.html?method=bkash&status=error`);
  }
});

// ---------------------------------------------------------------------
// 3. Nagad redirects here after the user approves/cancels payment
//    Nagad appends its own query params, including payment_ref_id & status
// ---------------------------------------------------------------------
router.get('/nagad/callback', (req, res) => {
  const { payment_ref_id: paymentReferenceId, status, order_id: orderId } = req.query;

  const order =
    orders.get(orderId) ||
    [...orders.values()].find((o) => o.meta.paymentReferenceId === paymentReferenceId);

  if (status === 'Success') {
    if (order) order.status = 'paid';
    return res.redirect(`/success.html?orderId=${order?.id || ''}`);
  }

  if (order) order.status = 'failed';
  return res.redirect(`/cancel.html?method=nagad&status=${status || 'unknown'}`);
});

// ---------------------------------------------------------------------
// 4. Check an order's status (poll from the frontend if you like)
// ---------------------------------------------------------------------
router.get('/order/:id', (req, res) => {
  const order = orders.get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found' });
  res.json(order);
});

module.exports = router;
