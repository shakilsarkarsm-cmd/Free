// services/bkash.js
// Implements bKash's "Tokenized Checkout" flow:
//   1. grantToken()      -> get an id_token
//   2. createPayment()   -> get a bKash-hosted checkout URL
//   3. executePayment()  -> confirm the payment after user returns
//
// Docs: https://developer.bka.sh/docs/tokenized-checkout-url-based

const axios = require('axios');

const BASE_URL = process.env.BKASH_BASE_URL;

let cachedToken = null;
let tokenExpiresAt = 0;

function authHeaders(idToken) {
  return {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    Authorization: idToken,
    'X-APP-Key': process.env.BKASH_APP_KEY,
  };
}

async function grantToken() {
  // Reuse the cached token until ~1 minute before it expires.
  if (cachedToken && Date.now() < tokenExpiresAt - 60_000) {
    return cachedToken;
  }

  const { data } = await axios.post(
    `${BASE_URL}/tokenized/checkout/token/grant`,
    {
      app_key: process.env.BKASH_APP_KEY,
      app_secret: process.env.BKASH_APP_SECRET,
    },
    {
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        username: process.env.BKASH_USERNAME,
        password: process.env.BKASH_PASSWORD,
      },
    }
  );

  if (!data.id_token) {
    throw new Error(`bKash token grant failed: ${JSON.stringify(data)}`);
  }

  cachedToken = data.id_token;
  // expires_in is in seconds
  tokenExpiresAt = Date.now() + Number(data.expires_in || 3600) * 1000;
  return cachedToken;
}

/**
 * Creates a payment and returns the bKash-hosted URL to redirect the user to.
 * @param {Object} opts
 * @param {string} opts.amount     e.g. "100.00"
 * @param {string} opts.orderId    your internal order/invoice id
 * @param {string} opts.callbackURL where bKash redirects after payment
 */
async function createPayment({ amount, orderId, callbackURL }) {
  const idToken = await grantToken();

  const { data } = await axios.post(
    `${BASE_URL}/tokenized/checkout/create`,
    {
      mode: '0011', // checkout (URL based)
      payerReference: orderId,
      callbackURL,
      amount: String(amount),
      currency: 'BDT',
      intent: 'sale',
      merchantInvoiceNumber: orderId,
    },
    { headers: authHeaders(idToken) }
  );

  if (!data.bkashURL) {
    throw new Error(`bKash create payment failed: ${JSON.stringify(data)}`);
  }

  return data; // includes paymentID and bkashURL
}

/**
 * Executes (confirms) a payment after the user is redirected back.
 * @param {string} paymentID
 */
async function executePayment(paymentID) {
  const idToken = await grantToken();

  const { data } = await axios.post(
    `${BASE_URL}/tokenized/checkout/execute`,
    { paymentID },
    { headers: authHeaders(idToken) }
  );

  return data; // check data.transactionStatus === 'Completed'
}

/**
 * Optional: query a payment's current status (useful for reconciliation).
 */
async function queryPayment(paymentID) {
  const idToken = await grantToken();

  const { data } = await axios.post(
    `${BASE_URL}/tokenized/checkout/payment/status`,
    { paymentID },
    { headers: authHeaders(idToken) }
  );

  return data;
}

module.exports = { grantToken, createPayment, executePayment, queryPayment };
