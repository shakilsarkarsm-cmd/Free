// services/nagad.js
// Implements Nagad's "Checkout API" flow:
//   1. initializePayment() -> get paymentReferenceId + challenge
//   2. completePayment()   -> get a Nagad-hosted callBackUrl to redirect the user to
//
// Nagad encrypts a JSON payload with THEIR public key (RSA, PKCS1 padding)
// and signs it with YOUR merchant private key (RSA-SHA256).
// You get both keys when you complete merchant onboarding:
// https://home.mynagad.com/merchant-integration/
//
// Docs (community-maintained, official docs are PDF given during onboarding):
// https://developer.mynagad.com/

const axios = require('axios');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const BASE_URL = process.env.NAGAD_BASE_URL;
const MERCHANT_ID = process.env.NAGAD_MERCHANT_ID;
const MERCHANT_NUMBER = process.env.NAGAD_MERCHANT_NUMBER;

function loadKey(envPathVar) {
  const p = process.env[envPathVar];
  if (!p) throw new Error(`Missing env var ${envPathVar}`);
  return fs.readFileSync(path.resolve(p), 'utf8');
}

function getMerchantPrivateKey() {
  return loadKey('NAGAD_MERCHANT_PRIVATE_KEY_PATH');
}

function getNagadPublicKey() {
  return loadKey('NAGAD_PUBLIC_KEY_PATH');
}

function sign(plainText) {
  const signer = crypto.createSign('SHA256');
  signer.update(plainText);
  signer.end();
  return signer.sign(getMerchantPrivateKey(), 'base64');
}

function encrypt(plainText) {
  return crypto
    .publicEncrypt(
      {
        key: getNagadPublicKey(),
        padding: crypto.constants.RSA_PKCS1_PADDING,
      },
      Buffer.from(plainText)
    )
    .toString('base64');
}

function decrypt(cipherText) {
  return crypto
    .privateDecrypt(
      {
        key: getMerchantPrivateKey(),
        padding: crypto.constants.RSA_PKCS1_PADDING,
      },
      Buffer.from(cipherText, 'base64')
    )
    .toString('utf8');
}

function timestamp() {
  // yyyyMMddHHmmss, Nagad expects Asia/Dhaka local time
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return (
    d.getFullYear() +
    pad(d.getMonth() + 1) +
    pad(d.getDate()) +
    pad(d.getHours()) +
    pad(d.getMinutes()) +
    pad(d.getSeconds())
  );
}

function randomChallenge() {
  return crypto.randomBytes(20).toString('hex');
}

const headers = (clientIp) => ({
  'Content-Type': 'application/json',
  'X-KM-Api-Version': 'v-0.2.0',
  'X-KM-IP-V4': clientIp || '127.0.0.1',
  'X-KM-Client-Type': 'PC_WEB',
});

/**
 * Step 1: initialize a payment.
 */
async function initializePayment({ orderId, clientIp }) {
  const dateTime = timestamp();
  const challenge = randomChallenge();

  const sensitivePlain = JSON.stringify({
    merchantId: MERCHANT_ID,
    datetime: dateTime,
    orderId,
    challenge,
  });

  const body = {
    accountNumber: MERCHANT_NUMBER,
    dateTime,
    sensitiveData: encrypt(sensitivePlain),
    signature: sign(sensitivePlain),
  };

  const { data } = await axios.post(
    `${BASE_URL}/api/dfs/check-out/initialize/${MERCHANT_ID}/${orderId}`,
    body,
    { headers: headers(clientIp) }
  );

  if (!data.paymentReferenceId) {
    throw new Error(`Nagad initialize failed: ${JSON.stringify(data)}`);
  }

  return { ...data, challenge }; // keep challenge for step 2
}

/**
 * Step 2: complete the payment, returns a URL to redirect the user to.
 */
async function completePayment({ orderId, paymentReferenceId, challenge, amount, callbackURL, clientIp }) {
  const sensitivePlain = JSON.stringify({
    merchantId: MERCHANT_ID,
    orderId,
    currencyCode: '050', // BDT
    amount: String(amount),
    challenge,
  });

  const body = {
    sensitiveData: encrypt(sensitivePlain),
    signature: sign(sensitivePlain),
    merchantCallbackURL: callbackURL,
    additionalMerchantInfo: {},
  };

  const { data } = await axios.post(
    `${BASE_URL}/api/dfs/check-out/complete/${paymentReferenceId}`,
    body,
    { headers: headers(clientIp) }
  );

  if (!data.callBackUrl) {
    throw new Error(`Nagad complete failed: ${JSON.stringify(data)}`);
  }

  return data; // { callBackUrl, ... } — redirect the user here
}

module.exports = { initializePayment, completePayment, decrypt };
